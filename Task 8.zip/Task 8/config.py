API_KEY = "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"
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"