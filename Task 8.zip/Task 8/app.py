from flask import Flask, render_template, request
import requests
from config import API_KEY, BASE_URL

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    weather = None

    if request.method == 'POST':
        city = request.form['city']

        url = f"{BASE_URL}?q={city}&appid={API_KEY}&units=metric"
        response = requests.get(url)
        data = response.json()

        if data.get("cod") != 404:
            weather = {
                "city": city,
                "temp": data["main"]["temp"],
                "desc": data["weather"][0]["description"],
                "humidity": data["main"]["humidity"]
            }
        else:
            weather = "City not found!"

    return render_template("index.html", weather=weather)

if __name__ == "__main__":
    app.run(debug=True)