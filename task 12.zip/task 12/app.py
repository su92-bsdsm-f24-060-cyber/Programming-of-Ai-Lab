from flask import Flask, render_template, request, jsonify
from model import get_answer

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    user_input = request.form["question"]
    answer = get_answer(user_input)
    return jsonify({"answer": answer})

if __name__ == "__main__":
    app.run(debug=True)