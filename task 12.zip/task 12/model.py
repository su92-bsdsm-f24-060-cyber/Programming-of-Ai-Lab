import pandas as pd
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# Load model (MiniLM)
model = SentenceTransformer('all-MiniLM-L6-v2')

# Load dataset
df = pd.read_csv("data.csv")

# Convert questions into embeddings
questions = df["question"].tolist()
embeddings = model.encode(questions)

# Convert to numpy
embeddings = np.array(embeddings).astype("float32")

# Create FAISS index
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(embeddings)

# Search function
def get_answer(query):
    query_vec = model.encode([query]).astype("float32")
    
    D, I = index.search(query_vec, k=1)
    
    return df.iloc[I[0][0]]["answer"]